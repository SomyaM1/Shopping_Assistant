package com.example.barkodershopapp.ui.listeners

import com.example.barkodershopapp.data.db.productdatabase.ProductDataEntity

interface onClickAddProduct {

    fun onAdedProduct(list : ProductDataEntity)
}