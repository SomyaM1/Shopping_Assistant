package com.example.barkodershopapp.ui.listeners

import com.example.barkodershopapp.data.db.listdatabase.ListDataEntity

interface OnCheckedListener {

    fun onCheckedChanged(list : ListDataEntity)
}